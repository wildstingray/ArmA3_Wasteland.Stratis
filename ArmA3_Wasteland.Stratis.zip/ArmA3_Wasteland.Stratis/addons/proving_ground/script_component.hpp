#define __path addons\proving_ground
#define __module main_
