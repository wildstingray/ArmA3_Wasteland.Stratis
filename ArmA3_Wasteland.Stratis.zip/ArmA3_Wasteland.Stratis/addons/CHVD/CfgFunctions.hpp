class CHVD
{
	tag = "CHVD";
	class script
	{
		file = "addons\CHVD";
		class onCheckedChanged {};
		class onSliderChange {};
		class onLBSelChanged {};
		class onEBinput {};
		class onEBterrainInput {};
		class selTerrainQuality {};
		class updateSettings {};
		class openDialog {};
		class localize {};
		class init {postInit = 1;};
	};
};