#include "R3F_ARTY_disable_enable.sqf"
#include "R3F_LOG_disable_enable.sqf"

#ifdef R3F_ARTY_enable
#include "R3F_ARTY\dlg_chef_batterie\dlg_saisie_mission.h"
#include "R3F_ARTY\dlg_chef_batterie\dlg_clic_carte.h"
#endif

#ifdef R3F_LOG_enable
#include "R3F_LOG\transporteur\dlg_contenu_vehicule.h"
#endif
