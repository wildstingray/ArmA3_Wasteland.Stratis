// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2014 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: respawn_defines.hpp
//	@file Author: [404] Deadbeat, [404] Costlyy, AgentRev

#define respawn_dialog 34287
#define respawn_Content_Text 3401
#define respawn_MissionUptime_Text 3402
// #define respawn_Town_Button0 3403
// #define respawn_Town_Button1 3404
// #define respawn_Town_Button2 3405
// #define respawn_Town_Button3 3406
// #define respawn_Town_Button4 3407
// #define respawn_PlayersInTown_Text0 3408
// #define respawn_PlayersInTown_Text1 3409
// #define respawn_PlayersInTown_Text2 3410
// #define respawn_PlayersInTown_Text3 3411
// #define respawn_PlayersInTown_Text4 3412
#define respawn_Random_Button 3413
// #define respawn_LoadTowns_Button 3414
// #define respawn_LoadBeacons_Button 3415
#define respawn_Preload_Checkbox 3416
#define respawn_Locations_Type 3449
#define respawn_Locations_List 3450
#define respawn_Locations_Map 3451
#define respawn_Locations_Text 3452
#define respawn_Spawn_Button 3453
#define respawn_GroupMgmt_Button 34600
